This is the dynamic code generation variant of the Node examples. Code in these examples is generated at runtime using Protobuf.js.
